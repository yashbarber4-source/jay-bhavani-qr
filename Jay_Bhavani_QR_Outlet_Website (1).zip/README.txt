# Netlify-ready static website

## Files
- index.html — main page
- styles.css — supplied site styling
- all.min.css — supplied Font Awesome CSS
- qrcode.min.js — supplied QRCode library
- fonts.css — supplied font CSS
- netlify.toml — Netlify publish configuration

## Before publishing
Open `index.html` and edit the `CONFIG` object near the bottom:
- name
- address
- phone
- swiggy

The QR code automatically uses the current page URL, so after Netlify publishes the site it will encode the live Netlify URL.

## Netlify
Drag the `netlify-ready` folder into Netlify Drop, or upload the contents as a new site.
