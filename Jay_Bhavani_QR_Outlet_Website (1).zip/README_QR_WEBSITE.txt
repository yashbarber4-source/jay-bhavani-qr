JAY BHAVANI QR OUTLET WEBSITE

1. Upload all files to Netlify.
2. Open the published Netlify URL.
3. The QR code automatically points to that live URL.
4. Print that QR on tables, counter cards, packaging, visiting cards, etc.
5. To create another outlet, duplicate the site and change the CONFIG section in index.html:
   - name
   - address
   - phone
   - whatsapp
   - swiggy
   - zomato
   - reviews

Current starter outlet data is based on the supplied website ZIP.
Zomato is a placeholder and should be replaced with the actual outlet URL.
